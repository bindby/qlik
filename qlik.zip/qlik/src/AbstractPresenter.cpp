#include "AbstractPresenter.h"

AbstractPresenter::AbstractPresenter()
{

}

AbstractPresenter::AbstractPresenter(string title)
{
    setTitle(title);
}
